function Mostrar()
{
//tomo la hora 
var laHora = document.getElementById('hora').value;

//alert (laHora);
	
	



}//FIN DE LA FUNCIÓN