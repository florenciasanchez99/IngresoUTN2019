function Mostrar()
{

var repetciones = prompt("ingrese el número de repeticiones");



}//FIN DE LA FUNCIÓN