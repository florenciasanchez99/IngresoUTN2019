function Mostrar()
{
	alert('iteración while');


}//FIN DE LA FUNCIÓN